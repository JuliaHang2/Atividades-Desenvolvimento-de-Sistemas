<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       
        body {
            background-color: #f9e5f0; 
            font-family: Arial, sans-serif;
            color: #4a0044; 
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        
        #fundo {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 900px;
            text-align: center;
        }

        
        h1 {
            color: #d36da0; 
            font-size: 24px;
            margin-bottom: 20px;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th, td {
            border: 1px solid #d36da0; 
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #ff80ab; 
            color: #4a0044;
        }

        
        button {
            background-color: #d36da0; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin: 5px;
        }

        button:hover {
            background-color: #f5a1c0; 
        }

        
        a {
            color: #d36da0; 
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            color: #f5a1c0; 
            text-decoration: underline;
        }

      
        form {
            margin-bottom: 20px;
        }

        form input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d36da0;
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        input[type="text"]:focus {
            border-color: #f5a1c0;
            outline: none;
        }

    </style>
</head>
<body>

<form action="usuarioAgendaSelect.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="pesquisar">Pesquisar</button></td>
        </tr>    
    </table>
</form>

<form action="usuarioAgendaInsert.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="inserir">Inserir</button></td>
        </tr>    
    </table>
</form>

<form action="" method="post">
<?php
if (isset($_POST["pesquisar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT nomeUsuario, senha, email, login, ativo, id FROM usuario;";
    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        echo '
        <table>
            <tr>
                <th>Nome Usuário</th>
                <th>Senha</th>
                <th>Email</th>
                <th>Login</th>
                <th>Ativo</th>
            </tr>';
        
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            echo '
            <tr>
                <td>'.$linha['nomeusuario'].'</td>
                <td>'.$linha['senha'].'</td>
                <td>'.$linha['email'].'</td>
                <td>'.$linha['login'].'</td>
                <td>'.($linha['ativo'] ? 'Sim' : 'Não').'</td>
                <td>
                    <a href="usuarioAgendaUpdate.php?id='.$linha['id'].'"><button type="button">Atualizar</button></a>
                    <form action="usuarioAgendaDelete.php" method="post" style="display:inline;">
                        <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                        <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este usuário?\');">Deletar</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</table>';
    } else {
        echo "Erro ao carregar os usuários.";
    }
}

if (isset($_POST['deletar_id'])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $deletar_id = $_POST['deletar_id'];
    $sql_delete = "DELETE FROM usuario WHERE id = :id";
    $stmt = $resultado->prepare($sql_delete);
    $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        echo "Usuário deletado com sucesso.";
    } else {
        echo "Erro ao deletar o usuário.";
    }
}
?>
</form>

</body>
</html>
