
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/styles/agenda.css">
    <title>Agenda</title>
</head>
<body>

    <form action="usuarioAgendaSelect.php" method="post">
        <table>
            
        <tr>
        <td colspan="2"><button id="botao" type="submit" name="pesquisar">Pesquisar</button></td>
        <td colspan="2"><button id="botao" type="submit" name="atualizar">Atualizar</button></td>
        </tr>    
    </table>
        
    </form>
</body>
</html>

<?php

    extract ($_POST);
    if(isset($_POST["pesquisar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT nomeUsuario, senha, email, login, ativo, id FROM usuario;";
        $indice = 0;

        $executado = $resultado->prepare($sql);

        if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }

            $i = 0;
            echo '
            <table>
                    <tr>
                        <td>Nome Usuário</td>
                        <td>Senha</td>
                        <td>Email</td>
                        <td>Login</td>
                        <td>Ativo</td>
                        <td>Número de Cadastro</td>
                    </tr>';
            while($i < $indice)
            {
            echo '
                
                    <tr>
                        <td>'.$linhas[$i]['nomeusuario'].'</td>
                        <td>'.$linhas[$i]['senha'].'</td>
                        <td>'.$linhas[$i]['email'].'</td>
                        <td>'.$linhas[$i]['login'].'</td>
                        <td>'.$linhas[$i]['ativo'].'</td>
                        <td>'.$linhas[$i]['id'].'</td>     
                    </tr>
            ';
            $i++;
            }
            echo '</table>';
        }
        else
        {
            echo "Erro.";
        }
    }
?>