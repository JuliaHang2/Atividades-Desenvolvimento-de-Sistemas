<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/styles/agenda.css">
    <title>Agenda</title>
</head>
<body>

<form action="contatosAgendaSelect.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="pesquisar">Pesquisar</button></td>
        </tr>    
    </table>
</form>

<form action="contatosAgendaInsert.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="inserir">Inserir</button></td>
        </tr>    
    </table>
</form>


<form action="" method="post">
<?php
extract($_POST);
if (isset($_POST["pesquisar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    
    if (isset($_POST['deletar_id'])) {
        $deletar_id = $_POST['deletar_id'];
        $sql_delete = "DELETE FROM contatos WHERE id = :id";
        $stmt = $resultado->prepare($sql_delete);
        $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            echo "Contato deletado com sucesso.";
        } else {
            echo "Erro ao deletar o contato.";
        }
    }

    $sql = "SELECT nome, endereco, telefone, email, celular, id FROM contatos;";
    $indice = 0;

    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }

        echo '
        <table>
            <tr>
                <td>Nome</td>
                <td>Endereco</td>
                <td>Telefone</td>
                <td>Email</td>
                <td>Celular</td>
            </tr>';
        
        for ($i = 0; $i < $indice; $i++) {
            echo '
            <tr>
                <td>'.$linhas[$i]['nome'].'</td>
                <td>'.$linhas[$i]['endereco'].'</td>
                <td>'.$linhas[$i]['telefone'].'</td>
                <td>'.$linhas[$i]['email'].'</td>
                <td>'.$linhas[$i]['celular'].'</td>
                <td>
                    
                    <a href="contatosAgendaUpdate.php?id='.$linhas[$i]['id'].'"><button type="button">Atualizar</button></a>
                    <button type="submit" name="deletar_id" value="'.$linhas[$i]['id'].'">Deletar</button>
                    
                    
                </td>
            </tr>';
        }
        echo '</table>';
    } else {
        echo "Erro ao carregar os contatos.";
    }
}
?>
</form>

</body>
</html>
