<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
        
        body {
            background-color: #f9e5f0; 
            font-family: Arial, sans-serif;
            color: #4a0044; 
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        
        #fundo {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 900px;
            text-align: center;
        }

        h1 {
            color: #d36da0;
            font-size: 24px;
            margin-bottom: 20px;
        }

      
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th, td {
            border: 1px solid #d36da0;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #ff80ab;
            color: #4a0044;
        }

        button {
            background-color: #d36da0; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin: 5px;
        }

        button:hover {
            background-color: #f5a1c0; 
        }

        
        a {
            color: #d36da0; 
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            color: #f5a1c0; 
            text-decoration: underline;
        }

        
        form {
            margin-bottom: 20px;
        }

        form input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d36da0;
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        input[type="text"]:focus {
            border-color: #f5a1c0;
            outline: none;
        }
        #login-bnt{
            position:absolute;
            top:90%;
            left:93%;
            width: 5%;
        }
        .pesquisa {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pesquisa input[type="text"] {
             margin-right: 10px;
        }

    </style>
</head>
<body>

<form action="contatosAgendaSelect.php" method="post">
    <table>
        <tr>
            <td colspan="2">
                <button id="botao" type="submit" name="pesquisar">Pesquisar Contatos</button>
            </td>
        </tr>    
    </table>

    <div class="pesquisa">
        <input type="text" id="letra" name="letra" placeholder="Digite um nome">
        <button id="bnt-busca" type="submit" name="buscar">Buscar</button>
    </div>
</form>


<form action="contatosAgendaInsert.php" method="post">
    <table>
        <tr>
            <td colspan="2">
                <button id="botao" type="submit" name="inserir">Inserir Contatos</button>
            </td>
        </tr>    
    </table>
</form>
<a href="login.php">
            <button type="button" id="login-bnt">Sair</button>
        </a>
<form action="" method="post">
<?php
extract($_POST);
if (isset($_POST["pesquisar"])) {

    
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT nome, endereco, telefone, email, celular, idfk,id FROM contatos WHERE idfk = ".$_SESSION["id"].";";
    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        echo '
        <table>
            <tr>
                <th>Nome</th>
                <th>Endereco</th>
                <th>Telefone</th>
                <th>Email</th>
                <th>Celular</th>
                <th>Ações</th>
            </tr>';
        
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            echo '
            <tr>
                <td>'.$linha['nome'].'</td>
                <td>'.$linha['endereco'].'</td>
                <td>'.$linha['telefone'].'</td>
                <td>'.$linha['email'].'</td>
                <td>'.$linha['celular'].'</td>
                <td>
                    <a href="contatosAgendaUpdate.php?id='.$linha['id'].'">
                        <button type="button">Atualizar</button>
                    </a>
                    <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                        <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                        <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</table>';
    } else {
        echo "Erro ao carregar os contatos.";
    }
}
if (isset($_POST["buscar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();
    
    $sql = "SELECT nome, endereco, telefone, email, celular, id FROM contatos WHERE nome like UPPER('".$_POST["letra"]."%') AND id = ".$_SESSION["id"].";";
    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        echo '
        <table>
            <tr>
                <th>Nome</th>
                <th>Endereco</th>
                <th>Telefone</th>
                <th>Email</th>
                <th>Celular</th>
                <th>Ações</th>
            </tr>';
        
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            echo '
            <tr>
                <td>'.$linha['nome'].'</td>
                <td>'.$linha['endereco'].'</td>
                <td>'.$linha['telefone'].'</td>
                <td>'.$linha['email'].'</td>
                <td>'.$linha['celular'].'</td>
                <td>
                    <a href="contatosAgendaUpdate.php?id='.$linha['id'].'">
                        <button type="button">Atualizar</button>
                    </a>
                    <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                        <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                        <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</table>';
    }
}

if (isset($_POST['deletar_id'])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $deletar_id = $_POST['deletar_id'];
    $sql_delete = "DELETE FROM contatos WHERE id = :id";
    $stmt = $resultado->prepare($sql_delete);
    $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        echo "Contato deletado com sucesso.";
    } else {
        echo "Erro ao deletar o contato.";
    }
}
?>
</form>


</body>
</html>
