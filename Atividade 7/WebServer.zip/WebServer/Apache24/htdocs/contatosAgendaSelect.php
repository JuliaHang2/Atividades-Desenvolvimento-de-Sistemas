<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
     
        body {
            background-color: #f8e1f4; 
            font-family: Arial, sans-serif;
            color: #4a0044; 
            margin: 0;
            padding: 20px;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th, td {
            border: 1px solid #d5006d; 
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #ff80ab; 
            color: #4a0044; 
        }

      
        button {
            background-color: #ff4081; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #c51162; 
        }

      
        a {
            color: #d5006d; 
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline; 
        }
    </style>
</head>
<body>

<form action="contatosAgendaSelect.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="pesquisar">Pesquisar Contatos</button></td>
        </tr>    
    </table>
</form>

<form action="contatosAgendaInsert.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="inserir">Inserir Contatos</button></td>
        </tr>    
    </table>
</form>

<form action="" method="post">
<?php
extract($_POST);
if (isset($_POST["pesquisar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT nome, endereco, telefone, email, celular, id FROM contatos;";
    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        echo '
        <table>
            <tr>
                <th>Nome</th>
                <th>Endereco</th>
                <th>Telefone</th>
                <th>Email</th>
                <th>Celular</th>
            </tr>';
        
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            echo '
            <tr>
                <td>'.$linha['nome'].'</td>
                <td>'.$linha['endereco'].'</td>
                <td>'.$linha['telefone'].'</td>
                <td>'.$linha['email'].'</td>
                <td>'.$linha['celular'].'</td>
                <td>
                    <a href="contatosAgendaUpdate.php?id='.$linha['id'].'"><button type="button">Atualizar</button></a>
                    <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                        <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                        <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</table>';
    } else {
        echo "Erro ao carregar os contatos.";
    }
}

if (isset($_POST['deletar_id'])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $deletar_id = $_POST['deletar_id'];
    $sql_delete = "DELETE FROM contatos WHERE id = :id";
    $stmt = $resultado->prepare($sql_delete);
    $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        echo "Contato deletado com sucesso.";
    } else {
        echo "Erro ao deletar o contato.";
    }
}
?>
</form>

</body>
</html>
