<?php
    session_name('iniciar');
    session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9e5f0; 
            color: #4a0044; 
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            position: relative;
        }

        h1 {
            color: #d36da0; 
            font-size: 24px;
            margin-bottom: 20px;
        }

        label {
            color: #d36da0; 
            font-weight: bold;
            margin: 10px 0 5px;
            display: block;
        }

        input[type="text"],
        input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d36da0;
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
            background-color: #fff;
            color: #4a0044; 
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #f5a1c0; 
            outline: none;
            box-shadow: 0 0 5px rgba(243, 158, 179, 0.6); 
        }

        button {
            background-color: #d36da0; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: background-color 0.3s;
            margin-bottom: 10px; 
        }

        button:hover {
            background-color: #f5a1c0; 
        }

     
        #cadastro-btn {
            background-color: #d36da0;
            color: #fff;
            border: 1px solid #d36da0;
        }

        #cadastro-btn:hover {
            background-color: #f5a1c0;
            color: white;
        }
        #a1{
            color: #d36da0; 
            text-decoration: none;
            font-weight: bold;
            display: block;
            text-align: center;
            margin-top: 20px;
            position:absolute;
            top:3%;
            left:3%;
        }
        #a1:hover{
            text-decoration:underline;
        }

    </style>
</head>

<body>
    <form action="login.php" method="post">
        <h1>Login</h1>
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>
        <br><br>

        <label for="password">Senha:</label>
        <input type="password" id="password" name="passwd" required>
        <br><br>

        <button id="button" type="submit" name="entrar">Entrar</button>

       
        <a href="usuarioAgendaInsert.php">
            <button type="button" id="cadastro-btn">Cadastre-se</button>
        </a>
    </form>
    <p><a id = "a1" href="usuarioAgendaSelect.php">Informações usuários</a></p>
</body>
</html>

<?php
    extract($_POST);
    if(isset($_POST["entrar"])) {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT nomeUsuario, senha FROM usuario WHERE nomeUsuario ='".$_POST["name"]."'AND senha = '".md5($_POST ["passwd"])."';";
        
        $query = $resultado->prepare($sql);
        $indice = 0;
        if ($query->execute()) {
            while($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                $linhas[$indice] = $linha;
                $indice++;
            }
            if($indice == 1) {
                $_SESSION["cadastro"] = TRUE;
                header("location: contatosAgendaSelect.php");
            } else {
                echo "Usuário e Senha não existem.";
            }
        }

        unset($_POST["entrar"], $_POST["name"], $_POST["passwd"]);
    }
?>
