<?php
    session_name('iniciar');
    session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    
    <form action="login.php" method="post">
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        
        <label for="password">Senha:</label>
        <input type="password" id="password" name="passwd" required>
        <br><br>
        
        <button id="button" type="submit" name="entrar">Entrar</button>
    </form>
    <form action="usuarioAgendaInsert.php" method="post">
    <table>
        <tr>
            <td colspan="2"><button id="botao" type="submit" name="cadastrar">Cadastre-se</button></td>
        </tr>    
    </table>
</form>
</body>
</html>

<?php


    extract($_POST);
    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT nomeUsuario, senha FROM usuario WHERE nomeUsuario ='".$_POST["name"]."'AND senha = '".md5($_POST ["passwd"])."';";
        
        $query = $resultado->prepare($sql);
        $indice = 0;
        if ($query->execute())
        {
            while($linha = $query->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }
            if($indice == 1)
            {
                $_SESSION["cadastro"] = TRUE;
                header("location: contatosAgendaSelect.php");
            } 
            else
            {
                echo "Usuario e Senha não existem.";
            }
        }

        unset($_POST["entrar"], $_POST["name"], $_POST["passwd"]);
    }
?>