<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$contato = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $sql = "SELECT nomeUsuario, senha, email, login, ativo, id FROM usuario WHERE id = :id;";
    $executado = $resultado->prepare($sql);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        $contato = $executado->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "Erro ao buscar usuário.";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['salvar'])) {
    $nomeUsuario = $_POST['nomeUsuario'];
    $senha = $_POST['senha'];
    $email = $_POST['email'];
    $login = $_POST['login'];
    $ativo = $_POST['ativo'];

    $sql = "UPDATE usuario SET nomeUsuario = :nomeUsuario, senha = :senha, email = :email, login = :login, ativo = :ativo WHERE id = :id;";
    $executado = $resultado->prepare($sql);
    
    $executado->bindParam(':nomeUsuario', $nomeUsuario);
    $executado->bindParam(':senha', $senha);
    $executado->bindParam(':email', $email);
    $executado->bindParam(':login', $login);
    $executado->bindParam(':ativo', $ativo);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        echo "Usuário atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar o usuário.";
    }
}
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Atualizar Usuário</title>
    <style>
        
        body {
            background-color: #f9e5f0; 
            font-family: Arial, sans-serif;
            color: #4a0044; 
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        
        h2 {
            color: #d36da0; 
            text-align: center;
            margin-bottom: 20px;
        }

        
        form {
            background-color: #fff; 
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        
        label {
            color: #d36da0; 
            font-weight: bold;
            margin: 10px 0 5px;
            display: block;
        }

       
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d36da0; 
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

      
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #f5a1c0; 
            outline: none;
        }

        
        input[type="submit"] {
            background-color: #d36da0;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: auto;
        }

        input[type="submit"]:hover {
            background-color: #f5a1c0; 
        }

        
        a {
            color: #d36da0;
            text-decoration: none;
            font-weight: bold;
            display: block;
            text-align: center;
            margin-top: 20px;
        }

        a:hover {
            color: #f5a1c0; 
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Atualizar Usuário</h2>
    <?php if ($contato): ?>
    <form action="" method="post">
        <label>Nome Usuário:</label>
        <input type="text" name="nomeUsuario" value="<?php echo htmlspecialchars($contato['nomeUsuario'] ?? ''); ?>" required>
        <br>
        <label>Senha:</label>
        <input type="password" name="senha" required>
        <br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($contato['email'] ?? ''); ?>" required>
        <br>
        <label>Login:</label>
        <input type="text" name="login" value="<?php echo htmlspecialchars($contato['login'] ?? ''); ?>" required>
        <br>
        <label>Ativo:</label>
        <input type="text" name="ativo" value="<?php echo htmlspecialchars($contato['ativo'] ?? ''); ?>" required>
        <br>
        <input type="submit" name="salvar" value="Salvar">
    </form>
    <?php else: ?>
        <p>Usuário não encontrado.</p>
    <?php endif; ?>
    <br>
    <a href="usuarioAgendaSelect.php">Voltar</a>
</body>
</html>
