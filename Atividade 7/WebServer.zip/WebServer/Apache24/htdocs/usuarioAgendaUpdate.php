<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       

    </style>
</head>
<body>
    
    <h1>Atualizar Contato</h1>
    <div id="fundo"></div>
    <form action="usuarioAgendaUpdate.php" method="post">
        <div>
        <label for="nomeUsuario">Nome de Usuário:</label>
        <input type="text" id="name" name="Atualizanome" required>      
        <br><br>
        
        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="Atualizasenha" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="Atualizaemail" required>
        <br><br>

        <label for="login">Login:</label>
        <input type="text" id="login" name="Atualizalogin" required>
        <br><br>


        <label for="id">Número de Cadastro:</label>
        <input type="text" id="id" name="id" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Atualizar</button><br><br>
    </form>
    <br>

</body>
</html>

<?php


    extract($_POST);

    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $id = $_POST['id'];
        $nomeUsuario = $_POST['Atualizanome'];
        $senha = $_POST['Atualizasenha'];
        $email = $_POST['Atualizaemail'];
        $login = $_POST['Atualizalogin'];

        $sql = "SELECT * FROM usuario WHERE id = $id";
        $sql = "UPDATE usuario SET nomeUsuario='".$nomeUsuario."', senha='".md5($senha)."',email='".$email."',login='".md5($login)."' where id=".$id.";";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            echo "Atualizou!";
        }
        else
        {
            echo "Erro ao atualizar, tente novamente!";
        }
    }

   

?>

