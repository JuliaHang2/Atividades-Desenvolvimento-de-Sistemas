<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$contato = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $sql = "SELECT nomeUsuario, senha, email, login, ativo, id FROM usuario WHERE id = :id;";
    $executado = $resultado->prepare($sql);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        $contato = $executado->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "Erro ao buscar usuário.";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['salvar'])) {
    $nomeUsuario = $_POST['nomeUsuario'];
    $senha = $_POST['senha'];
    $email = $_POST['email'];
    $login = $_POST['login'];
    $ativo = $_POST['ativo'];

    $sql = "UPDATE usuario SET nomeUsuario = :nomeUsuario, senha = :senha, email = :email, login = :login, ativo = :ativo WHERE id = :id;";
    $executado = $resultado->prepare($sql);
    
    $executado->bindParam(':nomeUsuario', $nomeUsuario);
    $executado->bindParam(':senha', $senha);
    $executado->bindParam(':email', $email);
    $executado->bindParam(':login', $login);
    $executado->bindParam(':ativo', $ativo);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        echo "Usuário atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar o usuário.";
    }
}
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Atualizar Usuário</title>
</head>
<body>
    <h2>Atualizar Usuário</h2>
    <?php if ($contato): ?>
    <form action="" method="post">
        <label>Nome Usuário:</label>
        <input type="text" name="nomeUsuario" value="<?php echo htmlspecialchars($contato['nomeUsuario'] ?? ''); ?>" required>
        <br>
        <label>Senha:</label>
        <input type="password" name="senha" required>
        <br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($contato['email'] ?? ''); ?>" required>
        <br>
        <label>Login:</label>
        <input type="text" name="login" value="<?php echo htmlspecialchars($contato['login'] ?? ''); ?>" required>
        <br>
        <label>Ativo:</label>
        <input type="text" name="ativo" value="<?php echo htmlspecialchars($contato['ativo'] ?? ''); ?>" required>
        <br>
        <input type="submit" name="salvar" value="Salvar">
    </form>
    <?php else: ?>
        <p>Usuário não encontrado.</p>
    <?php endif; ?>
    <br>
    <a href="usuarioAgendaSelect.php">Voltar</a>
</body>
</html>
