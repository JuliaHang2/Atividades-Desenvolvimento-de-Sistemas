<?php
session_name('iniciar');
session_start();


if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}


if (isset($_POST['deletar_id'])) {
    $id = $_POST['deletar_id'];
    
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

  
    $sql = "DELETE FROM contatos WHERE id = :id";
    $executado = $resultado->prepare($sql);
   
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
   
    if ($executado->execute()) {
        $_SESSION['mensagem'] = "Contato deletado com sucesso!";
    } else {
        $_SESSION['mensagem'] = "Erro ao deletar o contato.";
    }

    
    header("Location: contatosAgendaSelect.php");
    exit();
} else {
    
    $_SESSION['mensagem'] = "Nenhum contato selecionado para deletar.";
    header("Location: contatosAgendaSelect.php");
    exit();
}
?>
