<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       

    </style>
</head>
<body>
    
    <h1>Atualizar Contato</h1>
    <div id="fundo"></div>
    <form action="contatosAgendaInsert.php" method="post">
        <div>
        <label for="nome">Nome:</label>
        <input type="text" id="name" name="nome" required>      
        <br><br>
        
        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="endereco" required>
        <br><br>

        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        <br><br>

        <label for="celular">Celular:</label>
        <input type="text" id="celular" name="celular" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Atualizar</button><br><br>
    </form>
</body>
</html>

