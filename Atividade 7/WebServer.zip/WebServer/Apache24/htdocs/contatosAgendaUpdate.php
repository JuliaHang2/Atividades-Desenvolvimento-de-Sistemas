<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       

    </style>
</head>
<body>
    
    <h1>Atualizar Contato</h1>
    <div id="fundo"></div>
    <form action="contatosAgendaUpdate.php" method="post">
        <div>
        <label for="nome">Nome:</label>
        <input type="text" id="name" name="Atualizanome" required>      
        <br><br>
        
        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="Atualizaendereco" required>
        <br><br>

        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="Atualizatelefone" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="Atualizaemail" required>
        <br><br>

        <label for="celular">Celular:</label>
        <input type="text" id="celular" name="Atualizacelular" required>
        <br><br>

        <label for="id">Número de Cadastro:</label>
        <input type="text" id="id" name="id" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Atualizar</button><br><br>
    </form>
</body>
</html>

<?php


    extract($_POST);

    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $id = $_POST['id'];
        $nome = $_POST['Atualizanome'];
        $endereco = $_POST['Atualizaendereco'];
        $telefone = $_POST['Atualizatelefone'];
        $email = $_POST['Atualizaemail'];
        $celular =  $_POST['Atualizacelular'];

        $sql = "SELECT * FROM contatos WHERE id = $id";
        $sql = "UPDATE contatos SET nome='".$nome."', endereco='".$endereco."',telefone='".$telefone."',email='".$email."',celular='".$celular."' where id=".$id.";";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            echo "Atualizou!";
        }
        else
        {
            echo "Erro ao atualizar, tente novamente!";
        }
    }

   

?>

