<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT nome, endereco, telefone, email, celular FROM contatos WHERE id = :id";
    $executado = $resultado->prepare($sql);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        $contato = $executado->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "Erro ao buscar contato.";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['salvar'])) {
    $nome = $_POST['nome'];
    $endereco = $_POST['endereco'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $celular = $_POST['celular'];

    $sql = "UPDATE contatos SET nome = :nome, endereco = :endereco, telefone = :telefone, email = :email, celular = :celular WHERE id = :id";
    $executado = $resultado->prepare($sql);
    
    $executado->bindParam(':nome', $nome);
    $executado->bindParam(':endereco', $endereco);
    $executado->bindParam(':telefone', $telefone);
    $executado->bindParam(':email', $email);
    $executado->bindParam(':celular', $celular);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        echo "Contato atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar o contato.";
    }
}
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Atualizar Contato</title>
    <style>
        
        body {
            background-color: #f9e5f0; 
            font-family: Arial, sans-serif;
            color: #4a0044; 
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        
        h2 {
            color: #d36da0; 
            text-align: center;
            margin-bottom: 20px;
        }

        
        form {
            background-color: #fff; 
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

       
        label {
            color: #d36da0; 
            font-weight: bold;
            margin: 10px 0 5px;
            display: block;
        }

        
        input[type="text"],
        input[type="email"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d36da0; 
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

       
        input[type="text"]:focus,
        input[type="email"]:focus {
            border-color: #f5a1c0; 
            outline: none;
        }

      
        input[type="submit"] {
            background-color: #d36da0; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: auto;
        }

        input[type="submit"]:hover {
            background-color: #f5a1c0; 
        }

        
        a {
            color: #d36da0; 
            text-decoration: none;
            font-weight: bold;
            display: block;
            text-align: center;
            margin-top: 20px;
        }

        a:hover {
            color: #f5a1c0; 
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Atualizar Contato</h2>
    <form action="" method="post">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo $contato['nome']; ?>" required>
        <br>
        <label>Endereço:</label>
        <input type="text" name="endereco" value="<?php echo $contato['endereco']; ?>" required>
        <br>
        <label>Telefone:</label>
        <input type="text" name="telefone" value="<?php echo $contato['telefone']; ?>" required>
        <br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $contato['email']; ?>" required>
        <br>
        <label>Celular:</label>
        <input type="text" name="celular" value="<?php echo $contato['celular']; ?>" required>
        <br>
        <input type="submit" name="salvar" value="Salvar">
    </form>
    <br>
    <a href="contatosAgendaSelect.php">Voltar</a>
</body>
</html>