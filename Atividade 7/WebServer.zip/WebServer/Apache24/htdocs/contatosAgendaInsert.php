<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       
        body {
            background-color: #f8e1f4; 
            font-family: Arial, sans-serif;
            color: #4a0044; 
            margin: 0;
            padding: 20px;
        }

       
        #fundo {
            background-color: #fff; 
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

       
        h1 {
            color: #d5006d; 
            text-align: center;
        }

        
        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
        }

    
        input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d5006d; 
            border-radius: 5px;
            margin-bottom: 15px;
        }

    
        button {
            background-color: #ff4081; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #c51162; 
        }

        
        a {
            color: #d5006d; 
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline; 
        }
    </style>
</head>
<body>
    
    <div id="fundo">
        <h1>Inserir Contatos</h1> 
        <form action="contatosAgendaInsert.php" method="post">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" id="name" name="nome" required>      
                
                <label for="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco" required>

                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" required>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>

                <label for="celular">Celular:</label>
                <input type="text" id="celular" name="celular" required>

                <button id="button" type="submit" name="entrar">Cadastrar</button>
            </div>
        </form>
        <br>
        <a href="contatosAgendaSelect.php">Voltar</a>
    </div>
</body>
</html>




<?php


    extract($_POST);

    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "INSERT INTO contatos (nome,endereco,telefone,email,celular) VALUES ('".$_POST["nome"]."' , '".$_POST["endereco"]."' , '".$_POST["telefone"]."' , '".$_POST["email"]."' , '".$_POST["celular"]."');";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            echo "Cadastro realizado com sucesso!";
        }
        else
        {
            echo "Erro ao cadastrar, tente novamente!";
        }
    }

    unset($_POST["entrar"],$_POST["nome"],$_POST["endereco"],$_POST["email"],$_POST["telefone"],$_POST["celular"]);

?>