<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f9e5f0; 
            color: #4a0044; 
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        
        #fundo {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        
        h1 {
            color: #d36da0; 
            font-size: 24px;
            margin-bottom: 20px;
        }

      
        label {
            color: #d36da0; 
            font-weight: bold;
            margin: 10px 0 5px;
            display: block;
        }

       
        input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #d36da0; 
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        
        input[type="text"]:focus {
            border-color: #f5a1c0; 
            outline: none;
        }

        
        button {
            background-color: #d36da0; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #f5a1c0; 
        }

        
        a {
            display: block;
            margin-top: 20px;
            color: #d36da0; 
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            color: #f5a1c0; 
            text-decoration: underline;
        }

    </style>
</head>
<body>

    <div id="fundo">
        <h1>Inserir Contatos</h1>
        <form action="contatosAgendaInsert.php" method="post">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" id="name" name="nome" required>
                
                <label for="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco" required>

                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" required>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>

                <label for="celular">Celular:</label>
                <input type="text" id="celular" name="celular" required>

                <button id="button" type="submit" name="entrar">Cadastrar</button>
            </div>
        </form>
        <br>
        <a href="contatosAgendaSelect.php">Voltar</a>
    </div>

</body>
</html>

<?php
    extract($_POST);

    if(isset($_POST["entrar"])) {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

       

        $sql = "INSERT INTO contatos (nome, endereco, telefone, email, celular,idfk) 
                VALUES ('".$_POST["nome"]."', '".$_POST["endereco"]."', '".$_POST["telefone"]."', '".$_POST["email"]."', '".$_POST["celular"]."',".$_SESSION["id"].");";

        $query = $resultado->prepare($sql);
        if($query->execute()) {
            echo "Cadastro realizado com sucesso!";
        } else {
            echo "Erro ao cadastrar, tente novamente!";
        }
    }

    unset($_POST["entrar"], $_POST["nome"], $_POST["endereco"], $_POST["telefone"], $_POST["email"], $_POST["celular"]);
?>
