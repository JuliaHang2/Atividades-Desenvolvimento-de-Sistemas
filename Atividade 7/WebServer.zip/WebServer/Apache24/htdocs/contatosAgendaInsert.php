<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       

    </style>
</head>
<body>
    
    <div id="fundo"></div>
    <form action="contatosAgendaInsert.php" method="post">
        <div>
        <label for="nome">Nome:</label>
        <input type="text" id="name" name="nome" required>      
        <br><br>
        
        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="endereco" required>
        <br><br>

        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        <br><br>

        <label for="celular">Celular:</label>
        <input type="text" id="celular" name="celular" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Cadastrar</button><br><br>
    </form>
</body>
</html>


<?php


    extract($_POST);

    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "INSERT INTO contatos (nome,endereco,telefone,email,celular) VALUES ('".$_POST["nome"]."' , '".$_POST["endereco"]."' , '".$_POST["telefone"]."' , '".$_POST["email"]."' , '".$_POST["celular"]."');";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            echo "Cadastro realizado com sucesso!";
        }
        else
        {
            echo "Erro ao cadastrar, tente novamente!";
        }
    }

    unset($_POST["entrar"],$_POST["nome"],$_POST["endereco"],$_POST["email"],$_POST["telefone"],$_POST["celular"]);

?>