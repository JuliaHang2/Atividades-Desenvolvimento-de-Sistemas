

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       

    </style>
</head>
<body>
    
    <div id="fundo"></div>
    <form action="usuarioAgendaInsert.php" method="post">
        <div>
        <label for="name">Nome Usuário:</label>
        <input type="text" id="name" name="nomeUsuario" required>
        <br><br>
        
        <label for="password">Senha:</label>
        <input type="password" id="password" name="senha" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        <br><br><br>

        <label for="login">Login:</label>
        <input type="text" id="login" name="login" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Registrar</button><br><br>
    </form>
    <br>
    <a href="usuarioAgendaSelect.php">Voltar</a>
</body>
</html>

<?php

 


    extract($_POST);

    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $usuariocriptografado = md5($_POST["login"]);
        $senhacriptografada = md5($_POST["senha"]);

        $sql = "INSERT INTO usuario (nomeUsuario,senha,email,login,ativo) VALUES ('".$_POST["nomeUsuario"]."' , '".$senhacriptografada."' , '".$_POST["email"]."' , '".$usuariocriptografado."',TRUE);";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
            echo "Cadastro realizado com sucesso!";
        }
        else
        {
            echo "Erro ao cadastrar, tente novamente!";
        }
    }

    unset($_POST["entrar"],$_POST["nomeUsuario"],$_POST["senha"],$_POST["email"],$_POST["login"],$_POST["ativo"]);

?>