<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../agenda/style/insertContatos.css">
    <title>Agenda</title>
</head>
<body>

<div id="fundo">
    <h1>Inserir Contatos</h1>
    <form action="contatosAgendaInsert.php" method="post" enctype="multipart/form-data">
        <div>
            <label for="nome">Nome:</label>
            <input type="text" id="name" name="nome" required>
            
            <label for="endereco">Endereço:</label>
            <input type="text" id="endereco" name="endereco" required>

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="celular">Celular:</label>
            <input type="text" id="celular" name="celular" required>

            <label for="foto">Foto de Perfil:</label>
            <input type="file" name="arquivo">
            <br><br>

            <button id="button" type="submit" name="entrar">Cadastrar</button>
        </div>
    </form>
    <br>
    <a href="contatosAgendaSelect.php">Voltar</a>
</div>

</body>
</html>

<?php
extract($_POST);

if (isset($_POST["entrar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    
    $checkSql = "SELECT COUNT(*) FROM contatos WHERE nome = :nome OR email = :email OR telefone = :telefone";
    $checkQuery = $resultado->prepare($checkSql);
    $checkQuery->execute([
        ':nome' => $_POST["nome"],
        ':email' => $_POST["email"],
        ':telefone' => $_POST["telefone"]
    ]);
    $exists = $checkQuery->fetchColumn();

    if ($exists > 0) {
        echo "<script>alert('Este contato já está cadastrado!');</script>";
    } else {
        $destino = 'imagens/' . $_FILES['arquivo']['name'];
        $arquivo_tmp = $_FILES['arquivo']['tmp_name'];
        move_uploaded_file($arquivo_tmp, $destino);

        $sql = "INSERT INTO contatos (imagem, nome, endereco, telefone, email, celular, idfk) 
                VALUES (:imagem, :nome, :endereco, :telefone, :email, :celular, :idfk)";
        
        $query = $resultado->prepare($sql);
        $query->execute([
            ':imagem' => $destino,
            ':nome' => $_POST["nome"],
            ':endereco' => $_POST["endereco"],
            ':telefone' => $_POST["telefone"],
            ':email' => $_POST["email"],
            ':celular' => $_POST["celular"],
            ':idfk' => $_SESSION["id"]
        ]);

        if ($query) {
            echo "<script>alert('Cadastro realizado com sucesso!');</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar, tente novamente!');</script>";
        }
    }

    unset($_POST["entrar"], $_POST["nome"], $_POST["endereco"], $_POST["telefone"], $_POST["email"], $_POST["celular"]);
}


?>