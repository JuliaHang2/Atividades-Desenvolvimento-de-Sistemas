<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../agenda/style/insertContatos.css">
    <title>Agenda</title>
    
</head>
<body>

    <div id="fundo">
        <h1>Inserir Contatos</h1>
        <form action="contatosAgendaInsert.php" method="post">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" id="name" name="nome" required>
                
                <label for="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco" required>

                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" required>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>

                <label for="celular">Celular:</label>
                <input type="text" id="celular" name="celular" required>

                <button id="button" type="submit" name="entrar">Cadastrar</button>
            </div>
        </form>
        <br>
        <a href="contatosAgendaSelect.php">Voltar</a>
    </div>

</body>
</html>

<?php
    extract($_POST);

    if(isset($_POST["entrar"])) {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

       

        $sql = "INSERT INTO contatos (nome, endereco, telefone, email, celular,idfk) 
                VALUES ('".$_POST["nome"]."', '".$_POST["endereco"]."', '".$_POST["telefone"]."', '".$_POST["email"]."', '".$_POST["celular"]."',".$_SESSION["id"].");";

    $query = $resultado->prepare($sql);
        if ($query->execute()) {
            echo "<script>alert('Cadastro realizado com sucesso!');</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar, tente novamente!');</script>";
            }

    }


    unset($_POST["entrar"], $_POST["nome"], $_POST["endereco"], $_POST["telefone"], $_POST["email"], $_POST["celular"]);
?>
