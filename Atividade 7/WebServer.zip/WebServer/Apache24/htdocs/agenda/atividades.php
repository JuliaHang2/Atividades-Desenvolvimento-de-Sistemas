<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == false) {
    header("location: login.php");
    exit();
}

include('connect.php');
$obj = new connect();
$pdo = $obj->conectarBanco();

$idUsuario = $_SESSION['id']; 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nova_tarefa'])) {
    $tarefa = htmlspecialchars($_POST['nova_tarefa']);
    $data_entrega = $_POST['data_entrega']; 

    $sql = "INSERT INTO tarefas (tarefa, concluida, idfk, data_entrega) 
            VALUES (:tarefa, False, :idfk, :data_entrega)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':tarefa', $tarefa);
    $stmt->bindParam(':idfk', $idUsuario);
    $stmt->bindParam(':data_entrega', $data_entrega);
    $stmt->execute();
}

if (isset($_GET['concluir'])) {
    $idTarefa = intval($_GET['concluir']);
    $sql = "UPDATE tarefas SET concluida = True WHERE id_tarefas = :idTarefa AND idfk = :idfk";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':idTarefa', $idTarefa, PDO::PARAM_INT);
    $stmt->bindParam(':idfk', $idUsuario, PDO::PARAM_INT);
    $stmt->execute();
}

if (isset($_GET['excluir'])) {
    $idTarefa = intval($_GET['excluir']);
    $sql = "DELETE FROM tarefas WHERE id_tarefas = :idTarefa AND idfk = :idfk";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':idTarefa', $idTarefa, PDO::PARAM_INT);
    $stmt->bindParam(':idfk', $idUsuario, PDO::PARAM_INT);
    $stmt->execute();
}

$sql = "SELECT id_tarefas, tarefa, concluida, data_entrega FROM tarefas WHERE idfk = :idfk";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':idfk', $idUsuario, PDO::PARAM_INT);
$stmt->execute();
$tarefas = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../agenda/style/atividades.css">
    <title>Tarefas</title>
</head>
<body>
<header>
    <a href="contatosAgendaSelect.php"><button id="botao">Voltar</button></a>
    <h1>Atividades</h1>
</header>

<main>
    <form action="" method="POST" class="adicionar-tarefa">
        <input type="text" name="nova_tarefa" placeholder="Digite uma nova atividade" required>
        
        <input type="date" name="data_entrega" required>
        
        <button type="submit">Adicionar</button>
    </form>

    <ul class="lista-tarefas">
        <?php if (!empty($tarefas)): ?>
            <?php foreach ($tarefas as $tarefa): ?>
                <li class="<?= $tarefa['concluida'] ? 'concluida' : '' ?>">
                    <span><?= htmlspecialchars($tarefa['tarefa']) ?> 
                    (Data de entrega: <?= date('d/m/Y', strtotime($tarefa['data_entrega'])) ?>)</span>
                    <div class="acoes">
                        <?php if (!$tarefa['concluida']): ?>
                            <a href="?concluir=<?= $tarefa['id_tarefas'] ?>" class="btn-concluir">Concluir</a>
                        <?php endif; ?>
                        <a href="?excluir=<?= $tarefa['id_tarefas'] ?>" class="btn-excluir">Excluir</a>
                    </div>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
          
        <?php endif; ?>
    </ul>
</main>
</body>
</html>
