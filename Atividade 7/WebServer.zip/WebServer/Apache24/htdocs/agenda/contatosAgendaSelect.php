<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../agenda/style/selectContatos.css">
    <title>Agenda</title>
    
</head>
<body>

<a  href="../agenda/perfil.php" target="_blank">
    <img src="../agenda/imagens/icone.png" id="imgPerfil"/>
</a>

<a  href="../agenda/chat.php" target="_blank">
    <img src="../agenda/imagens/chat.png" id="imgChat"/>
</a>

<form action="contatosAgendaSelect.php" method="post">
    <table id="tabelaP">
        <tr>
            <td colspan="2">
                <button id="botao" type="submit" name="pesquisar">Pesquisar Contatos</button>
            </td>
        </tr>    
    </table>

    <div class="pesquisa">
        <input type="text" id="letra" name="letra" placeholder="Digite um nome">
        <button id="bnt-busca" type="submit" name="buscar">Buscar</button>
        </div>
</form>


<form action="contatosAgendaInsert.php" method="post">
    <table id="tabelaI">
        <tr>
            <td colspan="2">
                <button id="botao" type="submit" name="inserir">Inserir Contatos</button>
            </td>
        </tr>    
    </table>
</form>
<a href="login.php">
            <button type="button" id="login-bnt">Sair</button>
        </a>
<form action="" method="post">
<?php
extract($_POST);
if (isset($_POST["pesquisar"])) {

    
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT imagem, nome, endereco, telefone, email, celular, idfk,id FROM contatos WHERE idfk = ".$_SESSION["id"].";";
    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        echo '
        <table>
            <tr>
                <th>Imagem</th>
                <th>Nome</th>
                <th>Endereco</th>
                <th>Telefone</th>
                <th>Email</th>
                <th>Celular</th>
                <th>Ações</th>
            </tr>';
        
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            echo '
            <tr>
                <td><img width="35px" src="'.$linha['imagem'].'"/></td>
                <td>'.$linha['nome'].'</td>
                <td>'.$linha['endereco'].'</td>
                <td>'.$linha['telefone'].'</td>
                <td>'.$linha['email'].'</td>
                <td>'.$linha['celular'].'</td>
                <td>
                    <a href="contatosAgendaUpdate.php?id='.$linha['id'].'">
                        <button type="button">Atualizar</button>
                    </a>
                    <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                        <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                        <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</table>';
    } else {
        echo "<script>alert('Erro ao carregar contatos');</script>";
    }
}
if (isset($_POST["buscar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();
    
    $sql = "SELECT imagem, nome, endereco, telefone, email, celular, id, idfk FROM contatos WHERE nome like UPPER('".$_POST["letra"]."%') AND idfk = ".$_SESSION["id"].";";
    $executado = $resultado->prepare($sql);

    if ($executado->execute()) {
        echo '
        <table>
            <tr>
                <th>Imagem</th>
                <th>Nome</th>
                <th>Endereco</th>
                <th>Telefone</th>
                <th>Email</th>
                <th>Celular</th>
                <th>Ações</th>
            </tr>';
        
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            echo '
            <tr>
                <td><img width="35px" src="'.$linha['imagem'].'"/></td>
                <td>'.$linha['nome'].'</td>
                <td>'.$linha['endereco'].'</td>
                <td>'.$linha['telefone'].'</td>
                <td>'.$linha['email'].'</td>
                <td>'.$linha['celular'].'</td>
                <td>
                    <a href="contatosAgendaUpdate.php?id='.$linha['id'].'">
                        <button type="button">Atualizar</button>
                    </a>
                    <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                        <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                        <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</table>';
    }
}

if (isset($_POST['deletar_id'])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $deletar_id = $_POST['deletar_id'];
    $sql_delete = "DELETE FROM contatos WHERE id = :id";
    $stmt = $resultado->prepare($sql_delete);
    $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        echo "<script>alert('Contato deletado com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao deletar contato.');</script>";
    }
}
?>
</form>


</body>
</html>
