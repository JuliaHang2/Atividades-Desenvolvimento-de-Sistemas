<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
include_once("connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$contato = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $sql = "SELECT nomeUsuario, email, id FROM usuario WHERE id = :id;";
    $executado = $resultado->prepare($sql);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        $contato = $executado->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "<script>alert('Erro ao buscar o usuário.');</script>";
        exit();
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" href="../agenda/style/perfil.css"> 
</head>
<body>
    <div class="container">

     
        <div class="profile-header">
            <img src="../agenda/imagens/perfil.png" alt="Foto do usuário">
        </div>

        <?php if ($contato): ?>
        <form action="" method="post">
        <label id=p1><b>Nome:</b></label>
        <input type="text" name="nomeUsuario" value="<?php echo htmlspecialchars($contato['nomeUsuario'] ?? ''); ?>" required>
        <br>
        <label id=p1><b>Email:</b></label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($contato['email'] ?? ''); ?>" required>
        <br>
    </form>
    <?php else: ?>
        <p>Usuário não encontrado.</p>
    <?php endif; ?>
    
    <a href="editar_perfil.html" class="btn-edit">Editar Perfil</a>
    </div>
</body>
</html>
