<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$contato = null;
$erro = '';
$sucesso = '';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

   
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      
        $nomeUsuario = trim($_POST['nomeUsuario']);
        $email = trim($_POST['email']);
        
        
        $fotoPerfil = $_FILES['fotoPerfil'];

        
        if (empty($nomeUsuario) || empty($email)) {
            $erro = 'Nome e e-mail são obrigatórios.';
        } else {
          
            if ($fotoPerfil['error'] == 0) {
                $extensao = strtolower(pathinfo($fotoPerfil['name'], PATHINFO_EXTENSION));
                $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
                
                if (in_array($extensao, $extensoesPermitidas)) {
                   
                    $novoNome = 'perfil_' . $id . '.' . $extensao;
                    $diretorio = 'imagens/perfis/';
                    
                    
                    if (!is_dir($diretorio)) {
                        mkdir($diretorio, 0777, true); 
                    }

                    $caminhoCompleto = $diretorio . $novoNome;

                  
                    if (move_uploaded_file($fotoPerfil['tmp_name'], $caminhoCompleto)) {
                        
                        $sqlUpdate = "UPDATE usuario SET nomeUsuario = :nomeUsuario, email = :email, imagemUsuario = :imagemUsuario WHERE id = :id";
                        $executado = $resultado->prepare($sqlUpdate);
                        $executado->bindParam(':nomeUsuario', $nomeUsuario);
                        $executado->bindParam(':email', $email);
                        $executado->bindParam(':imagemUsuario', $caminhoCompleto); 
                        $executado->bindParam(':id', $id, PDO::PARAM_INT);

                        if ($executado->execute()) {
                            
                            header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $id);
                            exit();
                        } else {
                            $erro = 'Erro ao atualizar os dados.';
                        }
                    } else {
                        $erro = 'Erro ao fazer upload da imagem.';
                    }
                } else {
                    $erro = 'Formato de imagem inválido. Apenas JPG, JPEG, PNG e GIF são permitidos.';
                }
            } else {
               
                $erro = 'Erro no upload da imagem.';
            }
        }
    }

    $sql = "SELECT nomeUsuario, email, id, imagemUsuario FROM usuario WHERE id = :id;";
    $executado = $resultado->prepare($sql);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);

    if ($executado->execute()) {
        $contato = $executado->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "<script>alert('Erro ao buscar o usuário.');</script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" href="../agenda/style/perfil.css"> 
</head>
<body>
    <div class="container">
        <div class="profile-header">
            <?php if ($contato && $contato['imagemusuario']): ?>
                <img src="<?php echo $contato['imagemusuario']; ?>" alt="Foto do usuário" class="foto-perfil">
            <?php else: ?>
               
                <img src="../agenda/imagens/perfil.png" alt="Foto padrão" class="foto-perfil">
            <?php endif; ?>
        </div>

        <?php if ($contato): ?>
            <h2 style="color: #d36da0;">Perfil</h2>
            <?php if ($erro): ?>
                <p style="color: red;"><?php echo $erro; ?></p>
            <?php endif; ?>
            <?php if ($sucesso): ?>
                <p style="color: green;"><?php echo $sucesso; ?></p>
            <?php endif; ?>
            <form action="" method="post" enctype="multipart/form-data">
                <label id="p1"><b>Nome:</b></label>
                <input type="text" name="nomeUsuario" value="<?php echo htmlspecialchars($contato['nomeusuario'] ?? ''); ?>" required>
                <br>
                <label id="p1"><b>Email:</b></label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($contato['email'] ?? ''); ?>" required>
                <br>
                <label id="p1"><b>Foto de Perfil:</b></label>
                <input type="file" name="fotoPerfil" accept="image/*">
                <br><br>
                <input type="submit" value="Salvar">
                <a href="contatosAgendaSelect.php">
                    <button type="button" id="login-bnt">Voltar</button>
                </a>
            </form>
        <?php else: ?>
            <p>Usuário não encontrado.</p>
        <?php endif; ?>
    </div>
</body>
</html>
