<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("connect.php"); 

$obj = new connect();
$resultado = $obj->conectarBanco();


if (isset($_GET['id'])) {
    $deletar_id = $_GET['id'];
    $sql_delete = "DELETE FROM contatos WHERE id = :id";
    $stmt = $resultado->prepare($sql_delete);
    $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        echo "Contato deletado com sucesso.";
    } else {
        echo "Erro ao deletar o contato.";
    }
}


header("location: contatosAgendaSelect.php");
exit();
?>
