<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../agenda/style/chat.css">
    <title>Chat</title>
    <script type="text/javascript">
        function ajax() {
            var req = new XMLHttpRequest();
            req.onreadystatechange = function() {
                if (req.readyState == 4 && req.status == 200) {
                    document.getElementById('chat').innerHTML = req.responseText;
                }
            }
            req.open('GET', 'chat_refresh.php', true);
            req.send();
        }
    </script>
</head>
<body>
    <div id="chat">
        <?php
       
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();
        $sql = "SELECT nome, msg, user_id FROM chat";
        $query = $resultado->prepare($sql);
        $query->execute();
        
        while ($row = $query->fetch()) {
            $userClass = 'user' . $row['user_id']; 
            echo '<div><span class="' . htmlspecialchars($userClass) . '">' . htmlspecialchars($row['nome']) . ':</span> ' . htmlspecialchars($row['msg']) . '</div>';
        }
        ?>
    </div>
    <form action="chat.php" method="post">
        <div>
            <label for="name"><p id="campo"><b>Nome:</b></p></label>
            <input type="text" id="name" name="name" required>  
            <br /><br />
            <label for="msg"><p id="campo"><b>Mensagem:</b></p></label>
            <input type="text" id="msg" name="msg" required> 
            <button id="button" type="submit" name="Enviar">Enviar</button>
        </div>
    </form>
    <a href="contatosAgendaSelect.php"><button id="botao">Voltar</button></a>
</body>
</html>

<?php
extract($_POST);
if (isset($_POST["Enviar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "INSERT INTO chat (nome, msg, user_id) VALUES (?, ?, ?);"; 
    $query = $resultado->prepare($sql);
    
    
   
    $userId = 1;
	$query->execute([$_POST['name'], $_POST['msg'], $userId]);


    $_POST = [];
    header('Location: chat.php');
    exit();
}
?>
