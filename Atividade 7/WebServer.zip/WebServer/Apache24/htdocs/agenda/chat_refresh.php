<?php
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT * FROM chat ORDER BY id_chat DESC LIMIT 10";
    $query = $resultado->prepare($sql);

    if ($query->execute()) {
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            echo "<h3>" . htmlspecialchars($linha['nome']) . "</h3>";
            echo "<p>" . htmlspecialchars($linha['msg']) . "</p>";
        }
    }
?>