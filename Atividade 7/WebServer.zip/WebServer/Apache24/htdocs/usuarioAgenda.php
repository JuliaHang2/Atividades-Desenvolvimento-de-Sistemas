<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <style>
       

    </style>
</head>
<body>
    
    <div id="fundo"></div>
    <form action="usuarioAgenda.php" method="post">
        <div>
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        
        <label for="password">Senha:</label>
        <input type="password" id="password" name="password" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        <br><br><br>

        <label for="login">Login:</label>
        <input type="text" id="login" name="login" required>
        <br><br><br>

        <button id="button" type="submit" name="entrar">Registrar</button><br><br>
    </form>
</body>
</html>