<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/vagas.css">
    <title>Vagas</title>
</head>
<body>
    <header>
    <a href="../projeto/pagInicial.php"><i class='bx bxs-home'></i></a>
    <h1>VAGAS</h1>
    </header>



    <div class="retangulos">
        <div class="retangulo">
           <a href="../projeto/vaga1.php"> <img src="../projeto/imagens/vaga.jpg" alt="Curso 1" /> </a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 2" />
            <a href="link-para-curso-2.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 3" />
            <a href="link-para-curso-3.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 4" />
            <a href="link-para-curso-4.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 5" />
            <a href="link-para-curso-5.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 6" />
            <a href="link-para-curso-6.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 7" />
            <a href="link-para-curso-7.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 8" />
            <a href="link-para-curso-8.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 9" />
            <a href="link-para-curso-9.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
        <div class="retangulo">
            <img src="../projeto/imagens/vaga.jpg" alt="Curso 10" />
            <a href="link-para-curso-10.html"></a>
            <p>NOME DA EMPRESA: <br><br>
               ÁREA: <br><br>
               NÚMERO DE VAGAS:</p>
        </div>
    </div>

    <footer>
    <a href="../projeto/cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    <a href="../projeto/perfil.php"><i class='bx bxs-user-circle'></i></a>
    </footer>
    
</body>
</html>