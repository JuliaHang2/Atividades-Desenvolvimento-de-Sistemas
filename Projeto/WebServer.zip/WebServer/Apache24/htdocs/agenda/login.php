<?php
    session_name('iniciar');
    session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../agenda/style/login.css">
    <title>Login</title>
    
</head>

<body>
    <form action="login.php" method="post">
        <h1>Login</h1>
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>
        <br><br>

        <label for="password">Senha:</label>
        <input type="password" id="password" name="passwd" required>
        <br><br>

        <button id="button" type="submit" name="entrar">Entrar</button>

       
        <a href="usuarioAgendaInsert.php">
            <button type="button" id="cadastro-btn">Cadastre-se</button>
        </a>
    </form>
</body>
</html>

<?php
    extract($_POST);
    if(isset($_POST["entrar"])) {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT id,nomeUsuario, senha FROM usuario WHERE nomeUsuario ='".$_POST["name"]."'AND senha = '".md5($_POST ["passwd"])."';";
        
        $query = $resultado->prepare($sql);
        $indice = 0;
        if ($query->execute()) {
            while($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                $linhas[$indice] = $linha;
                $indice++;
            }
            if($indice == 1) {
                $_SESSION["cadastro"] = TRUE;
                $_SESSION["id"] = $linhas[0]["id"];
                header("location: contatosAgendaSelect.php");
            } else {
                echo "<script>alert('Usuário e senha não existem.');</script>";
            }
        }

        unset($_POST["entrar"], $_POST["name"], $_POST["passwd"]);
    }
?>
