<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT nome, endereco, telefone, email, celular FROM contatos WHERE id = :id";
    $executado = $resultado->prepare($sql);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        $contato = $executado->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "<script>alert('Erro ao buscar contato.');</script>";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['salvar'])) {
    $nome = $_POST['nome'];
    $endereco = $_POST['endereco'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $celular = $_POST['celular'];

    $sql = "UPDATE contatos SET nome = :nome, endereco = :endereco, telefone = :telefone, email = :email, celular = :celular WHERE id = :id";
    $executado = $resultado->prepare($sql);
    
    $executado->bindParam(':nome', $nome);
    $executado->bindParam(':endereco', $endereco);
    $executado->bindParam(':telefone', $telefone);
    $executado->bindParam(':email', $email);
    $executado->bindParam(':celular', $celular);
    $executado->bindParam(':id', $id, PDO::PARAM_INT);
    
    if ($executado->execute()) {
        echo "<script>alert('Contato atualizado com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao atualizar contato.');</script>";
    }
}
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../agenda/style/updateContatos.css">
    <title>Atualizar Contato</title>
    
</head>
<body>
    <h2>Atualizar Contato</h2>
    <form action="" method="post">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo $contato['nome']; ?>" required>
        <br>
        <label>Endereço:</label>
        <input type="text" name="endereco" value="<?php echo $contato['endereco']; ?>" required>
        <br>
        <label>Telefone:</label>
        <input type="text" name="telefone" value="<?php echo $contato['telefone']; ?>" required>
        <br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $contato['email']; ?>" required>
        <br>
        <label>Celular:</label>
        <input type="text" name="celular" value="<?php echo $contato['celular']; ?>" required>
        <br>
        <input type="submit" name="salvar" value="Salvar">
    </form>
    <br>
    <a href="contatosAgendaSelect.php">Voltar</a>
</body>
</html>